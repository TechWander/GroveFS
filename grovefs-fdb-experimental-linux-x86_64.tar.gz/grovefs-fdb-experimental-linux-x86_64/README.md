# GroveFS × FoundationDB 元数据后端 —— 自足投放包（实验档）

这个目录里的东西**不需要安装任何系统包**就能跑：`grovefs` 二进制、它要的那个 `libfdb_c.so`、
以及 FoundationDB 7.1.67 的三个官方制品，全都在包内，靠 ELF RUNPATH 与相对路径自解析。

> **口径先说清**：这一臂是**实验档**，不是 GroveFS 的第三个受支持后端。性能门 G3 判为未通过
> （同场对照：FDB 臂 24 单元最好 1601 ops/s，同一场 PG 臂 4100–4900 ops/s，RF=3，见
> `docs/fdb-keyspace.md` §15），风险处置 R3 已执行（不进默认板、文档撤下承诺、`--meta-store`
> 帮助里标 EXPERIMENTAL）。任何「FDB 已支持」的表述都是口径漂移。
> 本包只换**元数据权威**，数据面（对象存储、条带、GC）与 SQLite/PG 档完全一致。

## 目录结构

```
grovefs                              主二进制（feature `fdb` 已编入；符号表已剥离）
lib/libfdb_c.so                      FDB C 客户端库 —— 二进制运行期唯一的额外共享库
fdb/fdbserver                        官方 7.1.67 服务器（98 MB）
fdb/fdbcli                           官方 7.1.67 命令行（22 MB）
fdb/fdbmonitor                       官方 7.1.67 进程监护（1 MB）
BUILDINFO.txt                        构建坐标、依赖面、校验值
SHA256SUMS.txt                       全包逐文件校验
```

## 依赖面（这是本包存在的理由）

| 面 | 结论 |
|---|---|
| 运行期 | `ldd` 落地的额外共享库只有 glibc 核心（rt/dl/m/pthread）+ `libgcc_s`；`libfdb_c.so` 由 RUNPATH `$ORIGIN/lib:$ORIGIN/../lib` 解析到**包内那一份**，不需要 `LD_LIBRARY_PATH`，也不需要 `ldconfig` 里有 fdb_c 条目 |
| FDB 服务端 | 用包内 `fdb/fdbserver`，用户态起进程，**不装 `foundationdb-server` 包、不要 root** |
| 构建期 | 本包是产物，不含构建；但产出它的构建不再需要任何安装包——既不需要 libclang（`foundationdb-sys` 的绑定是预生成后 vendor 进来的，见 `docs/fdb-keyspace.md` §14 v2.0），也不需要 `pkg-config` 与 libfuse 开发包（`fuser` 未开 `libfuse*` feature、`rusqlite` 走 `bundled`；实测 `PKG_CONFIG=/nonexistent` 下 default 与 `--features fdb` 两种 release 构建均通过，产物 `DT_NEEDED` 无 fuse 库，配方 `.bneck/pkg_build_probe.sh`） |
| FUSE 挂载 | 不需要 **libfuse 开发包**，也不链 `libfuse.so`（挂载由 Rust `fuser` 完成）；但**非 root 挂载需要发行版的 setuid 助手 `fusermount`/`fusermount3`**（本机为 `/usr/bin/fusermount`，属 `fuse`/`fuse3` 包）。实测：uid 1005 直连 `mount(2)` 返 `EPERM`；把助手藏掉（`FUSERMOUNT_PATH=/nonexistent`）则 mount 进程直接报错退出，**不会假装挂载成功**（见下面「挂载面的边界」）。服务端与 `libfdb_c` 那一面完全不需要任何包 |

## 快速开始

### A. 已经有一个 FDB 集群

FDB 只换**元数据权威**，所以跑的是完整拓扑：`meta-server` 指 `--meta-store fdb://…`，
数据面仍由 `data-server` 承担，客户端只认 `--meta-server`（`mount` 本身没有 `--meta-store` 参数）。

```bash
sha256sum -c SHA256SUMS.txt                    # 先验完整性
./grovefs data-server --listen 127.0.0.1:50100 --data-dir /srv/grovefs/data &
./grovefs meta-server --listen 127.0.0.1:50053 --home /srv/grovefs/home \
    --meta-store fdb://<cluster 文件路径> &
# base tree 只能由显式命令建（挂载不建视图），--meta-dir 要与 meta-server 的 --home 同盘：
./grovefs view --meta-store fdb://<cluster 文件路径> --meta-dir /srv/grovefs/home create --view mydata
./grovefs view --meta-store fdb://<cluster 文件路径> --meta-dir /srv/grovefs/home list
mkdir /mnt/mydata
./grovefs --home /tmp/c1 mount --view mydata --mountpoint /mnt/mydata \
    --meta-server 127.0.0.1:50053 --data-servers 127.0.0.1:50100 --foreground
```

集群文件就是 `token:secret@host:port` 那行；`--meta-store` 是 `view` 的**组级**参数，
必须写在子命令名之前（`view --meta-store URI create …`，不是 `view create --meta-store URI …`）。
服务端启动横幅会打 `metadata backend foundationdb`——看不到这行就是静默降级到了 SQLite 档。

### B. 用包内制品起一个单机用户态集群（无 root、无安装包）

```bash
RUN=$(mktemp -d)
printf 'grovefs:devpass1@127.0.0.1:4500\n' > "$RUN/test.cluster"
setsid nohup ./fdb/fdbserver --cluster-file "$RUN/test.cluster" \
  -d "$RUN/data" -L "$RUN/logs" -l 127.0.0.1:4500 -p 127.0.0.1:4500 \
  -m 2000000 > "$RUN/server.out" 2>&1 &
# 等 "FDB joined cluster" 出现在 $RUN/server.out，然后一次性招募：
export FDB_CLUSTER_FILE="$RUN/test.cluster"
./fdb/fdbcli --exec "configure new single ssd"
./fdb/fdbcli --exec "status minimal"          # 必须打：The database is available.
```

`configure new single …` 之前集群永不答 `available`，次序必须是 joined → configure → available。
**`single` 意味着副本数 1**：这样的集群不能用来写任何持久性/可用性/性能承诺。
仓库里的等价脚本是 `.build-bin/fdb_env.sh`（`fetch` / `up` / `status` / `down` / `vars`），
它还会先对下载制品做 sha256 校验。

## 自足性验收（本包制作时逐条实跑过）

```bash
env -i PATH=/usr/bin:/bin ldd ./grovefs | grep libfdb_c
#   libfdb_c.so => <本目录>/lib/libfdb_c.so        ← 空环境下解析到包内
env -i PATH=/usr/bin:/bin ./grovefs --version
#   grovefs 0.1.0
env -i PATH=/usr/bin:/bin FDB_CLUSTER_FILE=<cluster> ./fdb/fdbcli --exec "status minimal"
#   The database is available.
env -i PATH=/usr/bin:/bin HOME=/tmp ./grovefs view --meta-store fdb://<cluster> create --view pkgprobe
#   created BASE view 'pkgprobe' in fdb://…
```

清掉这个探针视图（`fdbcli` 7.1 没有 `clearrangestartswith`，要用 `clearrange`，且写操作须先 `writemode on`）：

```bash
./fdb/fdbcli --exec "writemode on; clearrange \x01grovefs\x00\x02pkgprobe\x00 \x01grovefs\x00\x02pkgprobe\x01"
```

（视图的键前缀是 tuple 编码：`\x01grovefs\x00` 是 root，再 `\x02<视图名>\x00`。）

## 挂载面的边界（实测结论，不是免责声明）

本包的**不依赖安装包**指的是 `libfdb_c` 那一面：服务端、`view`、`data-server`、`fdbcli` 全部只靠包内文件就能跑。
但客户端的 `mount` 多一个东西要碰——内核 FUSE 的挂钩助手：

| 实验 | 结果 |
|---|---|
| 默认（`/usr/bin/fusermount` 存在）、非 root | 挂载成功，`fstype=fuse`，读写正常，`fusermount -u` 后 `/proc/mounts` 归 0 |
| 非 root、把助手藏掉（`FUSERMOUNT_PATH=/nonexistent`） | `mount(2)` 直连返 `EPERM` ⇒ `fuser` 回退到助手 ⇒ 找不到就直接失败（`error: No such file or directory`），挂载点目录**保持为空**，不会把字节写进裸目录当成挂载成功 |
| root / 有 `CAP_SYS_ADMIN` | **不依赖助手**。本机无 root，用 `unshare -r -m`（ns 内 uid 0、`CapEff=0000003fffffffff`）实测：`FUSERMOUNT_PATH=/nonexistent` 全程生效下仍挂载成功（`fstype=fuse`、`user_id=0,group_id=0`）、写读 mkdir 正常、`umount(2)` 也直连。注意这是 **user namespace 里的 root**，挂载只对那个 ns 可见；宿主真 root 未测，但走的同一条 `mount(2)` 分支 |

复现命令（两个脚本在 grovefs 源码仓库的 `.bneck/` 下，**不随本包投放**）：`bash .bneck/pkg_fusermount_probe.sh`（非 root 两组）与 `bash .bneck/pkg_rootns_probe.sh`（userns 内有 cap 的一组）。排查时注意一个坑：**用 `strace` 抓这一步会看到假的 EPERM**
——ptrace 会让 setuid 程序丢权，`fusermount` 因此失败；要么用 `FUSERMOUNT_PATH` 做对照，要么不用 `strace`。

另外两个入口完全不需要挂载点：`grovefs view …`（控制面）与 `grovefs gc/du/apikey` 等命令直接访问元数据，
所以只验证“树真的在 FDB 里”的话，连 FUSE 这一环都可以跳过。

## 已知语义与坑

- **跨视图共享账本**：`(root,'refs')` 是集群级的引用计数，GC 只在「本视图最后一个名字消失**且**计数归零」时才报释放。
  绕过 unlink 的销毁路径（直接删 subspace、`DROP SCHEMA CASCADE`）会留下**保守方向的多计**——
  字节宁可不删。补救是 `grovefs refs rebuild`（`src/gc.rs`）。详见 `docs/fdb-keyspace.md` §12 第 5 条。
- **强可串行化**：一个 POSIX 操作一个事务，冲突按 §6 映射成 errno，`not_committed` 绝不外泄给调用方。
- **键空间/编码已冻结**：API 版本固定 710；本包二进制若遇到别的 API 级别的集群，行为按设计直接拒绝而不是错链符号。

## 不在包里 / 不构成承诺的东西

不含 systemd unit、不含 `/etc/foundationdb/fdb.cluster`、不含 GUI/监控、不含源码；
不含 HA/多机房配置（`.bneck/fdb3_*` 那套三副本配方在仓库里，不在本包）；
不提供升级/回滚脚本。二进制来自一个 **clean 工作树**（`git status` 为空），实现内容对应提交
`ed87cbc`（见 `BUILDINFO.txt` 的「源码坐标」与「重编记录」）；但它**仍不是发布版**——没有 tag，
且容量决策门 G3 实测未通过，只用于实验与取证复现，勿在生产挂载点使用。
